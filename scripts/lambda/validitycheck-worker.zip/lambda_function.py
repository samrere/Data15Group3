import boto3
import pandas as pd
import requests
import io
import time
import random
import logging
from datetime import datetime 

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def check_job_validity(job_id: str) -> bool:
    """Check if a job posting is valid with retry for rate limiting"""
    url = f"https://www.linkedin.com/jobs/view/{job_id}"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5'
    }
    
    while True:  # Keep trying until we get a non-429 response
        try:
            response = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
            
            if response.status_code == 404:
                logger.info(f"Job post not found (404): {job_id}")
                return False
            elif response.status_code == 429:
                logger.info(f"Rate limit hit for job {job_id}. Waiting 10s before retry")
                time.sleep(10)
                continue  # Try again
            elif response.status_code == 200:
                final_url = response.url
                if "expired_jd_redirect" in final_url:
                    logger.info(f"Job post expired: {job_id}")
                    return False
                if "No longer accepting applications" in response.text:
                    logger.info(f"Job post closed: {job_id}")
                    return False
                logger.info(f"Job post active: {job_id}")
                return True
            else:
                logger.info(f"Unexpected status code {response.status_code}: {job_id}")
                return False
                
        except Exception as e:
            logger.error(f"Error checking {job_id}: {str(e)}")
            return False

def lambda_handler(event, context):
    try:
        start_time = datetime.now().strftime("%Y/%m/%d %H:%M:%S")
        logger.info(f"Lambda execution started at: {start_time}")

        s3 = boto3.client('s3')
        bucket = "data15group3-job-data-lake"
        
        start_idx = event['start_index']
        end_idx = event['end_index']
        logger.info(f"Processing jobs from index {start_idx} to {end_idx}")
        
        # Read job IDs
        response = s3.get_object(Bucket=bucket, Key="raw/job_id.csv")
        df_jobs = pd.read_csv(io.BytesIO(response['Body'].read()))
        
        # Get subset of jobs to process
        jobs_subset = df_jobs.iloc[start_idx:end_idx]
        
        # Process jobs
        invalid_jobs = []
        for job_id in jobs_subset['job_id']:
            if not check_job_validity(str(job_id)):
                invalid_jobs.append(job_id)
            time.sleep(random.uniform(2, 6))
        
        # Save results to temp location
        if invalid_jobs:
            df_invalid = pd.DataFrame({'job_id': invalid_jobs})
            temp_key = f"temp/worker_results/worker_{start_idx}_{end_idx}.parquet"
            
            parquet_buffer = io.BytesIO()
            df_invalid.to_parquet(parquet_buffer)
            s3.put_object(
                Bucket=bucket,
                Key=temp_key,
                Body=parquet_buffer.getvalue()
            )
        
        return {
            'statusCode': 200,
            'body': {
                'worker_range': f"{start_idx}-{end_idx}",
                'invalid_jobs_found': len(invalid_jobs),
                'lambda_start_time': start_time
            }
        }
        
    except Exception as e:
        logger.error(f"Error in worker lambda: {str(e)}")
        raise