"""
    linkedin-api
"""

from .linkedin import Linkedin

__all__ = ["Linkedin"]
